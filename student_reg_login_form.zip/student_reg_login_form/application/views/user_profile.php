<?php
    $this->load->helper('url');
  	$this->load->model('User_model');
    $this->load->library('session');
    $user_id= $this->session->userdata('user_id');

   
    if(!$user_id){

    // redirect('user/login_view');
    }
 ?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>User Profile Dashboard-CodeIgniter Login Registration</title>
    <link rel="stylesheet"  href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">    
  </head>

  <body>

<div class="container">
  <div class="row">
  <div class="col-md-6 col-md-offset-4">
      <table class="table table-bordered table-striped"  >
        <tr>
          <th colspan="2"><h3 class="text-center">User Details</h3></th>
        </tr>
		      <?php foreach($users as $user){ ?>
              <tr>
                <th>User Name</th>
                <td><?php echo $user['user_name']; ?></td>
              </tr>
              <tr>
                <th>User Email</th>
                <td><?php echo $user['user_email']; ?></td>
              </tr>
              <tr>
                <th>User Age</th>
                <td><?php echo  $user['user_age'];  ?></td>
              </tr>
              <tr>
                <th>User Mobile</th>
                <td><?php echo  $user['user_mobile']; ?></td>
              </tr>      
		      <?php } ?>
      </table>
      <a href="<?php echo base_url('index.php/User/user_logout');?>" >  
          <center><button type="button" class="btn-primary ">Logout</button></center>
        </a>
    </div>
  </div>

</div>
  </body>
</html>